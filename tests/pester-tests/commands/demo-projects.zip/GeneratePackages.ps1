$generateFewerPackages = $false

function CreatePackages()
{
    $wd = Get-Location
    Set-Location $PSScriptRoot\package-a
    . choco pack
    Set-Location $PSScriptRoot\package-b
    . choco pack
    Set-Location $PSScriptRoot\package-c
    . choco pack
    Set-Location $PSScriptRoot\package-d
    $start = if ($generateFewerPackages) { 990 } else { 0 }
    if ($generateFewerPackages) {
        for ($i = 0; $i -lt 11; $i++) {
            . choco pack
        }
    }
    for ($i = $start; $i -lt 1001; $i++) {
        . choco pack
    }
    Set-Location $PSScriptRoot\package-e
    if ($generateFewerPackages) {
        for ($i = 0; $i -lt 11; $i++) {
            . choco pack
        }
    }
    for ($i = $start; $i -lt 1001; $i++) {
        . choco pack
    }
    Set-Location $wd
}

CreatePackages
